package pe.edu.pe.SysVentas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysVentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
